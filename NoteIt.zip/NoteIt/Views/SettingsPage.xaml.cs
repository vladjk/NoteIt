﻿using Newtonsoft.Json;
using NoteIt.Models;
using NoteIt.ViewModels;
using System.Collections.Generic;
using System.Net.Http;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace NoteIt.Views
{
    public sealed partial class SettingsPage : Page
    {
        public SettingsViewModel ViewModel { get; } = new SettingsViewModel();

        /// <summary>Initializes a new instance of the <see cref="SettingsPage" /> class and enables caching for it.</summary>
        public SettingsPage()
        {
            InitializeComponent();
            
            this.NavigationCacheMode = NavigationCacheMode.Enabled;
        }

        /// <summary>Invoked when the Page is loaded and becomes the current source of a parent Frame. Loads user data from Donau on load.</summary>
        /// <param name="e">
        /// Event data that can be examined by overriding code. The event data is representative of the pending navigation that will load the current Page. Usually the most relevant property to examine is Parameter.
        /// </param>
        protected override async void OnNavigatedTo(NavigationEventArgs e)
        {
            HttpClient client = new HttpClient();
            var JsonResponse = await client.GetStringAsync("http://localhost:65076/api/Users");
            var UserResult = JsonConvert.DeserializeObject<List<User>>(JsonResponse);
            UserList.ItemsSource = UserResult;

            await ViewModel.InitializeAsync();
        }
    }
}
