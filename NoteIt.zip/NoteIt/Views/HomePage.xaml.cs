﻿using Newtonsoft.Json;
using NoteIt.Core.Helpers;
using NoteIt.Services;
using NoteIt.ViewModels;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Net.Http;
using System.Threading.Tasks;
using Windows.Data.Json;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace NoteIt.Views
{
    public sealed partial class HomePage : Page
    {
        public HomeViewModel ViewModel { get; } = new HomeViewModel();

        /// <summary>Initializes a new instance of the <see cref="HomePage" /> class and enables caching for this page.</summary>
        public HomePage()
        {
            InitializeComponent();
            this.NavigationCacheMode = NavigationCacheMode.Enabled;
        }

        /*CRUD Methods*/
        /// <summary>Gets the notes.</summary>
        public async Task GetNotes()
        {
            try
            {
                if (noteIdBox.Text != "")
                {
                    string requestUrl = "http://localhost:65076/api/Notes/" + noteIdBox.Text;

                    HttpClient client = new HttpClient();
                    string response = await client.GetStringAsync(requestUrl);

                    JsonObject jsonObj = JsonObject.Parse(response);
                    if (jsonObj.Count > 0)
                    {
                        char[] charTrim = { '"' };
                        string Title = jsonObj["noteTitle"].ToString().Trim(charTrim);
                        string Contents = jsonObj["noteContents"].ToString().Trim(charTrim);

                        noteTitleBox.Text = Title;
                        noteEditor.Document.SetText(Windows.UI.Text.TextSetOptions.FormatRtf, Contents);
                    }
                    else
                    {
                        Singleton<ToastNotificationsService>.Instance.ShowToastNotificationError();
                    }
                }
                else
                {
                    Singleton<ToastNotificationsService>.Instance.ShowToastNotificationNoInput();
                }
            }
            catch (Exception)
            {
                Singleton<ToastNotificationsService>.Instance.ShowToastNotificationIdNotFound();
                return;
            }


        }
        /// <summary>Deletes the notes.</summary>
        async Task DeleteNote()
        {
            try
            {
                if (noteIdBox.Text != "")
                {
                    string requestUrl = "http://localhost:65076/api/Notes/" + noteIdBox.Text;
                    var client = new HttpClient();
                    HttpResponseMessage response = await client.DeleteAsync(requestUrl);
                    string responseJsonText = await response.Content.ReadAsStringAsync();

                    if (noteIdBox.Text != responseJsonText)
                    {
                        noteTitleBox.Text = " ";
                        noteEditor.Document.SetText(Windows.UI.Text.TextSetOptions.None, " ");
                    }
                    /* Error Handling */
                    string normalT = responseJsonText;
                    string errorMessage = "404";
                    bool wrongId = normalT.Contains(errorMessage);
                    if (wrongId)
                    {
                        Singleton<ToastNotificationsService>.Instance.ShowToastNotificationIdNotFound();
                    }
                    else
                    {
                        Singleton<ToastNotificationsService>.Instance.ShowToastNotificationSuccessDelete();
                    }
                }
                else
                {
                    Singleton<ToastNotificationsService>.Instance.ShowToastNotificationNoInput();
                }

            }
            catch (Exception)
            {
                Singleton<ToastNotificationsService>.Instance.ShowToastNotificationIdNotFound();
                return;
            }
        }
        /// <summary>Posts the notes.</summary>
        async Task PostNotes()
        {
            if (noteIdBox.Text != "")
            {
                try
                {
                    string requestUrl = "http://localhost:65076/api/Notes/";
                    var client = new HttpClient();
                    dynamic dynamicData = new ExpandoObject();
                    int parsedId = int.Parse(noteIdBox.Text);
                    dynamicData.NoteId = parsedId;
                    dynamicData.NoteTitle = noteTitleBox.Text;
                    dynamicData.NoteContents = noteEditor.TextDocument.Selection.Text;
                    var json = JsonConvert.SerializeObject(dynamicData);
                    HttpResponseMessage response = await client.PostAsync(requestUrl, new StringContent(json, System.Text.Encoding.UTF8, "application/json"));
                    string responseJsonText = await response.Content.ReadAsStringAsync();

                    /* Error Handling */
                    string normalT = responseJsonText;
                    string errorMessage = "Bad Request";
                    bool wrongId = normalT.Contains(errorMessage);
                    if (!wrongId)
                    {
                        Singleton<ToastNotificationsService>.Instance.ShowToastNotificationPostSuccess();
                    }
                    else
                    {
                        Singleton<ToastNotificationsService>.Instance.ShowToastNotificationExists();
                    }

                }
                catch (Exception)
                {
                    Singleton<ToastNotificationsService>.Instance.ShowToastNotificationError();
                    return;
                }
            }
            else
            {
                Singleton<ToastNotificationsService>.Instance.ShowToastNotificationNoInput();
            }
        }

        /// <summary>Patches the notes.</summary>
        public async Task PatchNotes()
        {
            if (noteIdBox.Text != "")
            {
                try
                {
                    string requestUrl = "http://localhost:65076/api/Notes/" + noteIdBox.Text;
                    var client = new HttpClient();
                    dynamic dynamicData = new ExpandoObject();
                    int parsedId = int.Parse(noteIdBox.Text);
                    dynamicData.NoteId = parsedId;
                    dynamicData.NoteTitle = noteTitleBox.Text;
                    dynamicData.NoteContents = noteEditor.TextDocument.Selection.Text;
                    var json = JsonConvert.SerializeObject(dynamicData);
                    HttpResponseMessage response = await client.PutAsync(requestUrl, new StringContent(json, System.Text.Encoding.UTF8, "application/json"));
                    string responseJsonText = await response.Content.ReadAsStringAsync();

                    /* Error Handling */
                    string normalT = responseJsonText;
                    string errorMessage = "404";
                    bool wrongId = normalT.Contains(errorMessage);
                    if (!wrongId)
                    {
                        Singleton<ToastNotificationsService>.Instance.ShowToastNotificationPostSuccess();
                    }
                    else
                    {
                        Singleton<ToastNotificationsService>.Instance.ShowToastNotificationIdNotFound();
                    }

                }
                catch (Exception)
                {
                    Singleton<ToastNotificationsService>.Instance.ShowToastNotificationError();
                    return;
                }
            }
            else
            {
                Singleton<ToastNotificationsService>.Instance.ShowToastNotificationNoInput();
            }
        }

        /*Text Manipulation Methods*/
        /// <summary>Handles the Click event of the OpenButton control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        /// Opens stream and awaits for a file, either .rtf or .txt format
        /// Code inspired by code example of RichTextEdit from Microsoft. Source: https://docs.microsoft.com/en-us/windows/uwp/design/controls-and-patterns/rich-edit-box
        private async void OpenFileButton_Click(object sender, RoutedEventArgs e)
        {
            // Open a text file.
            Windows.Storage.Pickers.FileOpenPicker open = new Windows.Storage.Pickers.FileOpenPicker();
            open.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.DocumentsLibrary;
            open.FileTypeFilter.Add(".rtf");

            Windows.Storage.StorageFile file = await open.PickSingleFileAsync();

            if (file != null)
            {
                try
                {
                    Windows.Storage.Streams.IRandomAccessStream randAccStream =
                    await file.OpenAsync(Windows.Storage.FileAccessMode.Read);
                    noteEditor.Document.LoadFromStream(Windows.UI.Text.TextSetOptions.FormatRtf, randAccStream);
                }
                catch (Exception)
                {
                    Singleton<ToastNotificationsService>.Instance.ShowToastNotificationFileError();
                }
            }
        }

        /// <summary>Handles the Click event of the SaveFileButton control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="RoutedEventArgs" /> instance containing the event data.</param>
        /// Reads in rtf. format files and opens them via stream.
        private async void SaveFileButton_Click(object sender, RoutedEventArgs e)
        {
            Windows.Storage.Pickers.FileSavePicker savePicker = new Windows.Storage.Pickers.FileSavePicker();
            savePicker.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.DocumentsLibrary;
            savePicker.FileTypeChoices.Add("Rich Text", new List<string>() { ".rtf" });
            savePicker.SuggestedFileName = "New Note";

            Windows.Storage.StorageFile file = await savePicker.PickSaveFileAsync();
            if (file != null)
            {
                Windows.Storage.CachedFileManager.DeferUpdates(file);
                Windows.Storage.Streams.IRandomAccessStream randAccStream =
                await file.OpenAsync(Windows.Storage.FileAccessMode.ReadWrite);
                noteEditor.Document.SaveToStream(Windows.UI.Text.TextGetOptions.FormatRtf, randAccStream);

                Windows.Storage.Provider.FileUpdateStatus status = await Windows.Storage.CachedFileManager.CompleteUpdatesAsync(file);
                if (status != Windows.Storage.Provider.FileUpdateStatus.Complete)
                {
                    Windows.UI.Popups.MessageDialog errorBox =
                    new Windows.UI.Popups.MessageDialog("File " + file.Name + " couldn't be saved.");
                    await errorBox.ShowAsync();
                }
            }
        }

        private void BoldButton_Click(object sender, RoutedEventArgs e)
        {
            Windows.UI.Text.ITextSelection selectedText = noteEditor.Document.Selection;
            if (selectedText != null)
            {
                Windows.UI.Text.ITextCharacterFormat charFormatting = selectedText.CharacterFormat;
                charFormatting.Bold = Windows.UI.Text.FormatEffect.Toggle;

                selectedText.CharacterFormat = charFormatting;
            }
        }

        private void ItalicButton_Click(object sender, RoutedEventArgs e)
        {
            Windows.UI.Text.ITextSelection selectedText = noteEditor.Document.Selection;
            if (selectedText != null)
            {
                Windows.UI.Text.ITextCharacterFormat charFormatting = selectedText.CharacterFormat;
                charFormatting.Italic = Windows.UI.Text.FormatEffect.Toggle;
                selectedText.CharacterFormat = charFormatting;
            }
        }

        private void UnderlineButton_Click(object sender, RoutedEventArgs e)
        {
            Windows.UI.Text.ITextSelection selectedText = noteEditor.Document.Selection;
            if (selectedText != null)
            {
                Windows.UI.Text.ITextCharacterFormat charFormatting = selectedText.CharacterFormat;
                if (charFormatting.Underline == Windows.UI.Text.UnderlineType.None)
                {
                    charFormatting.Underline = Windows.UI.Text.UnderlineType.Single;
                }
                else
                {
                    charFormatting.Underline = Windows.UI.Text.UnderlineType.None;
                }
                selectedText.CharacterFormat = charFormatting;
            }
        }

        private void FontSizeButton_Click(object sender, RoutedEventArgs e)
        {
            Windows.UI.Text.ITextSelection selectedText = noteEditor.Document.Selection;
            if (selectedText != null)
            {
                Windows.UI.Text.ITextCharacterFormat charFormatting = selectedText.CharacterFormat;
                if (charFormatting.Size != 18)
                {
                    charFormatting.Size = 18;
                    selectedText.CharacterFormat = charFormatting;

                }
                else
                {
                    charFormatting.Size = 11;
                    selectedText.CharacterFormat = charFormatting;

                }
            }
        }

        private void clearBoxButton_Click(object sender, RoutedEventArgs e)
        {
            noteTitleBox.Text = "";
            noteIdBox.Text = "";
            noteEditor.Document.SetText(Windows.UI.Text.TextSetOptions.None, "");
        }

        /*CRUD Method Calls*/
        private async void SyncDatabaseButton_Click(object sender, RoutedEventArgs e) => await PatchNotes();
        private async void PostDatabaseButton_Click(object sender, RoutedEventArgs e) => await PostNotes();
        private async void DeleteDatabaseButton_Click(object sender, RoutedEventArgs e) => await DeleteNote();
        private async void GetDatabaseButton_Click(object sender, RoutedEventArgs e) => await GetNotes();


    }
}
