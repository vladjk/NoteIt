﻿
using NoteIt.Helpers;

namespace NoteIt.ViewModels
{
    public class HomeViewModel : Observable
    {
        public HomeViewModel()
        {
        }

    }
}
