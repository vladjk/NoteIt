﻿namespace NoteIt.Models
{
    class Note
    {
        public int NoteId { get; set; }
        public string NoteTitle { get; set; }
        public string NoteContents { get; set; }
    }
}
