﻿namespace NoteIt.API.Models
{
    public partial class User
    {
        public User()
        {
        }
        public int UserId { get; set; }
        public string UserName { get; set; }

    }
}
