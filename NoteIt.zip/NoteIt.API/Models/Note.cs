﻿namespace NoteIt.API.Models
{
    public partial class Note
    {
        public Note()
        {
        }
        public int NoteId { get; set; }
        public string NoteTitle { get; set; }
        public string NoteContents { get; set; }
    }

}
