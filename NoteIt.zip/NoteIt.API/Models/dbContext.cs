﻿using Microsoft.EntityFrameworkCore;

namespace NoteIt.API.Models
{
    public partial class dbContext : DbContext
    {
        public dbContext()
        {
        }
        public dbContext(DbContextOptions<dbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Note> Notes { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Note>(entity =>
            {
                entity.Property(e => e.NoteId).ValueGeneratedNever();
                entity.Property(e => e.NoteTitle).ValueGeneratedNever();
                entity.Property(e => e.NoteContents).ValueGeneratedNever();
            });
            modelBuilder.Entity<User>(entity =>
            {
                entity.Property(e => e.UserId).ValueGeneratedNever();
                entity.Property(e => e.UserName).ValueGeneratedNever();
            });
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
