﻿namespace NoteIt.Core.Models
{
    class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int NoteId { get; set; }
        public string NoteContents { get; set; }
    }
}
